'use client';
import ServicesPage from "../components/service/service";
export default function Testimonials() {
    return (
        <>
            <ServicesPage />
        </>
    )

}