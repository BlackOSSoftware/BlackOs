import PricingPlans from "../components/Pricing/pricing";

export default function Pricing() {
    return(
        <>
            <PricingPlans />
        </>
    )
}