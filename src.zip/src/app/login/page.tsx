import LoginPage from "../components/login/Login";

export default function AuthPage() {
    return(
        <>
            <LoginPage />
        </>
    )
}