import MinerList from "../components/miner/minerList";

export default function Page() {
  return <MinerList />;
}
