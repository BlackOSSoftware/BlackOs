"use client";


export default function Dashboard() {
  return (
    <main className="space-y-6">
      <h1 className="text-2xl font-bold text-[var(--color-primary)]">Dashboard Overview</h1>

    </main>
  );
}
