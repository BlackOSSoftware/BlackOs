import ContactForm from "../components/contact/Contact";

export default function ContactUS() {
  return (
    <ContactForm />
  );
}
